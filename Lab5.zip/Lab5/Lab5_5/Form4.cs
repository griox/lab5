namespace frmBai5_4

{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void btnDangnhap_Click(object sender, EventArgs e)
        {
            string tenDangNhap = txtTendangnhap.Text;
            string matKhau = txtMatkhau.Text;

            if (tenDangNhap == "admin" && matKhau == "password")
            {
                this.Close();
            }
            else
            {
                MessageBox.Show("T�n truy nh?p ho?c m?t kh?u kh�ng ?�ng. Vui l�ng th? l?i.", "Th�ng b�o");
            }
        }
    }
}
