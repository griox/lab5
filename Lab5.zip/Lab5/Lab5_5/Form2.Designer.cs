﻿namespace frmBai5_2
{
    partial class Form2
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            groupBox1 = new GroupBox();
            rbtnBac2 = new RadioButton();
            rbtnBac1 = new RadioButton();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            txtBoxa = new TextBox();
            txtBoxb = new TextBox();
            txtBoxc = new TextBox();
            txtBoxkq = new TextBox();
            label5 = new Label();
            button1 = new Button();
            button2 = new Button();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Brown;
            label1.Location = new Point(275, 36);
            label1.Name = "label1";
            label1.Size = new Size(262, 38);
            label1.TabIndex = 0;
            label1.Text = "Giải Phương Trình";
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(rbtnBac2);
            groupBox1.Controls.Add(rbtnBac1);
            groupBox1.Font = new Font("Segoe UI", 9F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            groupBox1.Location = new Point(35, 121);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(279, 122);
            groupBox1.TabIndex = 2;
            groupBox1.TabStop = false;
            groupBox1.Text = "Chọn phương trình";
            // 
            // rbtnBac2
            // 
            rbtnBac2.AutoSize = true;
            rbtnBac2.Location = new Point(28, 73);
            rbtnBac2.Name = "rbtnBac2";
            rbtnBac2.Size = new Size(166, 24);
            rbtnBac2.TabIndex = 1;
            rbtnBac2.TabStop = true;
            rbtnBac2.Text = "Phương trình bậc 2";
            rbtnBac2.UseVisualStyleBackColor = true;
            rbtnBac2.CheckedChanged += rbtnBac2_CheckedChanged;
            // 
            // rbtnBac1
            // 
            rbtnBac1.AutoSize = true;
            rbtnBac1.Location = new Point(28, 41);
            rbtnBac1.Name = "rbtnBac1";
            rbtnBac1.Size = new Size(166, 24);
            rbtnBac1.TabIndex = 0;
            rbtnBac1.TabStop = true;
            rbtnBac1.Text = "Phương trình bậc 1";
            rbtnBac1.UseVisualStyleBackColor = true;
            rbtnBac1.CheckedChanged += rbtnBac1_CheckedChanged;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.Gray;
            label2.Location = new Point(396, 133);
            label2.Name = "label2";
            label2.Size = new Size(60, 20);
            label2.TabIndex = 3;
            label2.Text = "Hệ số a";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.Gray;
            label3.Location = new Point(396, 178);
            label3.Name = "label3";
            label3.Size = new Size(61, 20);
            label3.TabIndex = 4;
            label3.Text = "Hệ số b";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.Gray;
            label4.Location = new Point(396, 225);
            label4.Name = "label4";
            label4.Size = new Size(59, 20);
            label4.TabIndex = 5;
            label4.Text = "Hệ số c";
            // 
            // txtBoxa
            // 
            txtBoxa.Location = new Point(487, 133);
            txtBoxa.Name = "txtBoxa";
            txtBoxa.Size = new Size(247, 27);
            txtBoxa.TabIndex = 6;
            // 
            // txtBoxb
            // 
            txtBoxb.Location = new Point(487, 179);
            txtBoxb.Name = "txtBoxb";
            txtBoxb.Size = new Size(247, 27);
            txtBoxb.TabIndex = 7;
            // 
            // txtBoxc
            // 
            txtBoxc.Location = new Point(487, 223);
            txtBoxc.Name = "txtBoxc";
            txtBoxc.Size = new Size(247, 27);
            txtBoxc.TabIndex = 8;
            // 
            // txtBoxkq
            // 
            txtBoxkq.Enabled = false;
            txtBoxkq.Location = new Point(157, 297);
            txtBoxkq.Name = "txtBoxkq";
            txtBoxkq.ReadOnly = true;
            txtBoxkq.Size = new Size(501, 27);
            txtBoxkq.TabIndex = 9;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.Gray;
            label5.Location = new Point(63, 297);
            label5.Name = "label5";
            label5.Size = new Size(63, 20);
            label5.TabIndex = 10;
            label5.Text = "Kết quả";
            // 
            // button1
            // 
            button1.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.ForeColor = Color.Brown;
            button1.Location = new Point(211, 362);
            button1.Name = "button1";
            button1.Size = new Size(103, 41);
            button1.TabIndex = 11;
            button1.Text = "Giải";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.ForeColor = Color.Brown;
            button2.Location = new Point(487, 362);
            button2.Name = "button2";
            button2.Size = new Size(103, 41);
            button2.TabIndex = 12;
            button2.Text = "Đóng";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(label5);
            Controls.Add(txtBoxkq);
            Controls.Add(txtBoxc);
            Controls.Add(txtBoxb);
            Controls.Add(txtBoxa);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(groupBox1);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private GroupBox groupBox1;
        private RadioButton rbtnBac2;
        private RadioButton rbtnBac1;
        private Label label2;
        private Label label3;
        private Label label4;
        private TextBox txtBoxa;
        private TextBox txtBoxb;
        private TextBox txtBoxc;
        private TextBox txtBoxkq;
        private Label label5;
        private Button button1;
        private Button button2;
    }
}
