using System.Windows.Forms;

namespace frmBai5_2
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void rbtnBac1_CheckedChanged(object sender, EventArgs e)
        {
            if (rbtnBac1.Checked)
                this.txtBoxc.Enabled = false;

        }

        private void rbtnBac2_CheckedChanged(object sender, EventArgs e)
        {
            if (rbtnBac2.Checked)
                this.txtBoxc.Enabled = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double a, b;
            if (!rbtnBac1.Checked && !rbtnBac2.Checked)
                MessageBox.Show("Chon 1 trong 2 phuong trinh!", "Thong bao", MessageBoxButtons.OK, MessageBoxIcon.Information);
            else if (!double.TryParse(this.txtBoxa.Text, out a) || a == 0)
                MessageBox.Show("a phai khac 0", "Thong bao", MessageBoxButtons.OK, MessageBoxIcon.Information);
            else if (!double.TryParse(this.txtBoxb.Text, out b))
                MessageBox.Show("b phai la 1 so", "Thong bao", MessageBoxButtons.OK, MessageBoxIcon.Information);
            else if (rbtnBac1.Checked)
            {
                this.txtBoxkq.Text = "x =" + Math.Round(-b / a, 2).ToString();
            }
            else
            {
                double c;
                if (!double.TryParse(this.txtBoxc.Text, out c))
                    MessageBox.Show("c phai la 1 so", "Thong bao", MessageBoxButtons.OK, MessageBoxIcon.Information);
                double delta = b * b - 4 * a * c;
                if (delta == 0)
                    this.txtBoxkq.Text = "x1 = x2 =" + Math.Round(-b / (2 * a), 2).ToString();
                else if (delta < 0)
                    this.txtBoxkq.Text = "Vo nghiem!";
                else
                {
                    double x1 = Math.Round((-b - Math.Sqrt(delta)) / (2 * a), 2);
                    double x2 = Math.Round((-b + Math.Sqrt(delta)) / (2 * a), 2);
                    this.txtBoxkq.Text = "x1 = " + x1 + ", x2 = " + x2;
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
