﻿namespace frmBai5_5
{
    partial class Form5
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            menuStrip1 = new MenuStrip();
            ToolStripMenu = new ToolStripMenuItem();
            ToolStripMenuItem1 = new ToolStripMenuItem();
            ToolStripMenuItem2 = new ToolStripMenuItem();
            ToolStripMenu2 = new ToolStripMenuItem();
            ToolStripMenuItem3 = new ToolStripMenuItem();
            ToolStripMenu3 = new ToolStripMenuItem();
            ToolStripMenuItem4 = new ToolStripMenuItem();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.ImageScalingSize = new Size(20, 20);
            menuStrip1.Items.AddRange(new ToolStripItem[] { ToolStripMenu, ToolStripMenu2, ToolStripMenu3 });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(800, 28);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // ToolStripMenu
            // 
            ToolStripMenu.DropDownItems.AddRange(new ToolStripItem[] { ToolStripMenuItem1, ToolStripMenuItem2 });
            ToolStripMenu.Name = "ToolStripMenu";
            ToolStripMenu.Size = new Size(85, 24);
            ToolStripMenu.Text = "Hệ thống";
            // 
            // ToolStripMenuItem1
            // 
            ToolStripMenuItem1.Name = "ToolStripMenuItem1";
            ToolStripMenuItem1.Size = new Size(224, 26);
            ToolStripMenuItem1.Text = "Đăng nhập";
            ToolStripMenuItem1.Click += ToolStripMenuItem1_Click_1;
            // 
            // ToolStripMenuItem2
            // 
            ToolStripMenuItem2.Name = "ToolStripMenuItem2";
            ToolStripMenuItem2.Size = new Size(224, 26);
            ToolStripMenuItem2.Text = "Thoát";
            ToolStripMenuItem2.Click += thoátToolStripMenuItem_Click;
            // 
            // ToolStripMenu2
            // 
            ToolStripMenu2.DropDownItems.AddRange(new ToolStripItem[] { ToolStripMenuItem3 });
            ToolStripMenu2.Name = "ToolStripMenu2";
            ToolStripMenu2.Size = new Size(186, 24);
            ToolStripMenu2.Text = "BT các điều khiển cơ bản";
            // 
            // ToolStripMenuItem3
            // 
            ToolStripMenuItem3.Name = "ToolStripMenuItem3";
            ToolStripMenuItem3.Size = new Size(134, 26);
            ToolStripMenuItem3.Text = "BT 5_2";
            ToolStripMenuItem3.Click += ToolStripMenuItem3_Click;
            // 
            // ToolStripMenu3
            // 
            ToolStripMenu3.AccessibleDescription = "";
            ToolStripMenu3.DropDownItems.AddRange(new ToolStripItem[] { ToolStripMenuItem4 });
            ToolStripMenu3.Name = "ToolStripMenu3";
            ToolStripMenu3.Size = new Size(202, 24);
            ToolStripMenu3.Text = "BT các điều khiển nâng cao";
            // 
            // ToolStripMenuItem4
            // 
            ToolStripMenuItem4.Name = "ToolStripMenuItem4";
            ToolStripMenuItem4.Size = new Size(224, 26);
            ToolStripMenuItem4.Text = "BT 5_3";
            ToolStripMenuItem4.Click += ToolStripMenuItem4_Click;
            // 
            // Form5
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "Form5";
            Text = "Form1";
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem ToolStripMenu;
        private ToolStripMenuItem ToolStripMenuItem1;
        private ToolStripMenuItem ToolStripMenuItem2;
        private ToolStripMenuItem ToolStripMenu2;
        private ToolStripMenuItem ToolStripMenuItem3;
        private ToolStripMenuItem ToolStripMenu3;
        private ToolStripMenuItem ToolStripMenuItem4;
    }
}
