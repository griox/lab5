﻿namespace frmBai5_3
{
    partial class Form3
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            txtMaso = new TextBox();
            txtGianhap = new TextBox();
            txtGiaban = new TextBox();
            cmbNhanhieu = new ComboBox();
            pictureBox1 = new PictureBox();
            label6 = new Label();
            btnAdd = new Button();
            btnDel = new Button();
            btnCalc = new Button();
            btnSort = new Button();
            btnClose = new Button();
            dgvPhone = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvPhone).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Brown;
            label1.Location = new Point(282, 29);
            label1.Name = "label1";
            label1.Size = new Size(287, 38);
            label1.TabIndex = 0;
            label1.Text = "Thông tin điện thoại";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold);
            label2.ForeColor = Color.FromArgb(192, 0, 0);
            label2.Location = new Point(40, 135);
            label2.Name = "label2";
            label2.Size = new Size(50, 20);
            label2.TabIndex = 1;
            label2.Text = "Mã số";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold);
            label3.ForeColor = Color.FromArgb(192, 0, 0);
            label3.Location = new Point(40, 184);
            label3.Name = "label3";
            label3.Size = new Size(81, 20);
            label3.TabIndex = 2;
            label3.Text = "Nhãn hiệu";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold);
            label4.ForeColor = Color.FromArgb(192, 0, 0);
            label4.Location = new Point(40, 282);
            label4.Name = "label4";
            label4.Size = new Size(61, 20);
            label4.TabIndex = 3;
            label4.Text = "Giá bán";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold);
            label5.ForeColor = Color.FromArgb(192, 0, 0);
            label5.Location = new Point(40, 233);
            label5.Name = "label5";
            label5.Size = new Size(70, 20);
            label5.TabIndex = 4;
            label5.Text = "Giá nhập";
            // 
            // txtMaso
            // 
            txtMaso.BackColor = SystemColors.Window;
            txtMaso.Location = new Point(147, 132);
            txtMaso.Name = "txtMaso";
            txtMaso.Size = new Size(353, 27);
            txtMaso.TabIndex = 5;
            // 
            // txtGianhap
            // 
            txtGianhap.BackColor = SystemColors.Window;
            txtGianhap.Location = new Point(147, 230);
            txtGianhap.Name = "txtGianhap";
            txtGianhap.Size = new Size(353, 27);
            txtGianhap.TabIndex = 6;
            // 
            // txtGiaban
            // 
            txtGiaban.BackColor = SystemColors.Window;
            txtGiaban.Location = new Point(147, 279);
            txtGiaban.Name = "txtGiaban";
            txtGiaban.ReadOnly = true;
            txtGiaban.Size = new Size(353, 27);
            txtGiaban.TabIndex = 8;
            // 
            // cmbNhanhieu
            // 
            cmbNhanhieu.ForeColor = SystemColors.Window;
            cmbNhanhieu.FormattingEnabled = true;
            cmbNhanhieu.Location = new Point(147, 181);
            cmbNhanhieu.Name = "cmbNhanhieu";
            cmbNhanhieu.Size = new Size(353, 28);
            cmbNhanhieu.TabIndex = 9;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = frmBai5_5.Properties.Resources.Phone2;
            pictureBox1.Location = new Point(587, 106);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(229, 229);
            pictureBox1.TabIndex = 18;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click_1;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(678, 74);
            label6.Name = "label6";
            label6.Size = new Size(68, 20);
            label6.TabIndex = 11;
            label6.Text = "Hình ảnh";
            // 
            // btnAdd
            // 
            btnAdd.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold);
            btnAdd.ForeColor = Color.FromArgb(0, 0, 192);
            btnAdd.Location = new Point(152, 379);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(94, 29);
            btnAdd.TabIndex = 12;
            btnAdd.Text = "Thêm";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            // 
            // btnDel
            // 
            btnDel.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold);
            btnDel.ForeColor = Color.FromArgb(0, 0, 192);
            btnDel.Location = new Point(252, 379);
            btnDel.Name = "btnDel";
            btnDel.Size = new Size(94, 29);
            btnDel.TabIndex = 13;
            btnDel.Text = "Xóa";
            btnDel.UseVisualStyleBackColor = true;
            btnDel.Click += btnDel_Click;
            // 
            // btnCalc
            // 
            btnCalc.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold);
            btnCalc.ForeColor = Color.FromArgb(0, 0, 192);
            btnCalc.Location = new Point(352, 379);
            btnCalc.Name = "btnCalc";
            btnCalc.Size = new Size(129, 29);
            btnCalc.TabIndex = 15;
            btnCalc.Text = "Tính giá bán";
            btnCalc.UseVisualStyleBackColor = true;
            btnCalc.Click += btnCalc_Click;
            // 
            // btnSort
            // 
            btnSort.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold);
            btnSort.ForeColor = Color.FromArgb(0, 0, 192);
            btnSort.Location = new Point(487, 379);
            btnSort.Name = "btnSort";
            btnSort.Size = new Size(94, 29);
            btnSort.TabIndex = 14;
            btnSort.Text = "Sắp xếp";
            btnSort.UseVisualStyleBackColor = true;
            btnSort.Click += btnSort_Click;
            // 
            // btnClose
            // 
            btnClose.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold);
            btnClose.ForeColor = Color.FromArgb(0, 0, 192);
            btnClose.Location = new Point(587, 379);
            btnClose.Name = "btnClose";
            btnClose.Size = new Size(94, 29);
            btnClose.TabIndex = 16;
            btnClose.Text = "Đóng";
            btnClose.UseVisualStyleBackColor = true;
            btnClose.Click += btnClose_Click;
            // 
            // dgvPhone
            // 
            dgvPhone.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvPhone.Location = new Point(136, 414);
            dgvPhone.Name = "dgvPhone";
            dgvPhone.RowHeadersWidth = 51;
            dgvPhone.Size = new Size(567, 124);
            dgvPhone.TabIndex = 17;
            // 
            // Form3
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.Control;
            ClientSize = new Size(869, 575);
            Controls.Add(dgvPhone);
            Controls.Add(btnClose);
            Controls.Add(btnCalc);
            Controls.Add(btnSort);
            Controls.Add(btnDel);
            Controls.Add(btnAdd);
            Controls.Add(label6);
            Controls.Add(pictureBox1);
            Controls.Add(cmbNhanhieu);
            Controls.Add(txtGiaban);
            Controls.Add(txtGianhap);
            Controls.Add(txtMaso);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form3";
            Text = "Phones";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvPhone).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private TextBox txtMaso;
        private TextBox txtGianhap;
        private TextBox txtGiaban;
        private ComboBox cmbNhanhieu;
        private PictureBox pictureBox1;
        private Label label6;
        private Button btnAdd;
        private Button btnDel;
        private Button btnCalc;
        private Button btnSort;
        private Button btnClose;
        private DataGridView dgvPhone;
    }
}
