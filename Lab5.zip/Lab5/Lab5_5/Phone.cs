﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace frmBai5_3
{
    internal class Phone : IComparable<Phone>
    {
        public string MaSo { get; set; }
        public string NhanHieu { get; set; }
        public double GiaNhap { get; set; }
        public string HinhAnh { get; set; }

        public double TinhGiaBan()
        {
            if (NhanHieu.ToLower() == "Iphone")
            {
                return 1.5 * GiaNhap;
            }
            else
            {
                return 1.3 * GiaNhap;
            }
        }

        public int CompareTo(Phone other)
        {
            return other.GiaNhap.CompareTo(GiaNhap);
        }
    }
}
