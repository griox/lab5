﻿namespace frmBai5_3
{
    public partial class Form3 : Form
    {
        List<Phone> ls;
        string path;

        public Form3()
        {
            InitializeComponent();
        }
        public void Read_File()
        {
            ls = new List<Phone>();
            try
            {
                FileStream f = new FileStream("C:\\C#\\phone.txt", FileMode.Open, FileAccess.Read);
                StreamReader rd = new StreamReader(f);

                while (!rd.EndOfStream)
                {
                    string maSo = rd.ReadLine();
                    string nhanHieu = rd.ReadLine();
                    double giaNhap = double.Parse(rd.ReadLine());
                    string hinhAnh = rd.ReadLine();

                    Phone phone = new Phone
                    {
                        MaSo = maSo,
                        NhanHieu = nhanHieu,
                        GiaNhap = giaNhap,
                        HinhAnh = hinhAnh
                    };

                    ls.Add(phone);

                    if (!rd.EndOfStream)
                    {
                        rd.ReadLine();
                    }
                }

                rd.Close();
                f.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }



        private void Form1_Load(object sender, EventArgs e)
        {
            Read_File();
            dgvPhone.DataSource = ls;
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            Phone p = ls.Find(c => c.MaSo == txtMaso.Text);

            if (p != null)
                txtGiaban.Text = p.TinhGiaBan().ToString();
        }


        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtMaso.Text) && !string.IsNullOrEmpty(cmbNhanhieu.Text) && !string.IsNullOrEmpty(txtGianhap.Text) && !string.IsNullOrEmpty(path))
            {
                Phone ph = new Phone
                {
                    MaSo = txtMaso.Text,
                    NhanHieu = cmbNhanhieu.Text,
                    GiaNhap = float.Parse(txtGianhap.Text),
                    HinhAnh = path
                };
                ls.Add(ph);
                dgvPhone.DataSource = null; //cập nhật lại nguồn dữ liệu cho dgvPhone
                dgvPhone.DataSource = ls;
                txtMaso.Text = "";
                txtGianhap.Clear();

            }
            else
            {
                MessageBox.Show("Vui lòng nhập đầy đủ thông tin.");
            }

        }

        private void btnDel_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < ls.Count; i++)
                if (ls[i].MaSo == txtMaso.Text)
                {
                    ls.RemoveAt(i);
                    break;
                }
            dgvPhone.DataSource = null;
            dgvPhone.DataSource = ls;
            txtMaso.Text = "";
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnSort_Click(object sender, EventArgs e)
        {
            ls.Sort(); //sử dụng điều kiện sắp xếp trong phương thức CompareTo 
            dgvPhone.DataSource = null;
            dgvPhone.DataSource = ls;
        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {
            OpenFileDialog file = new OpenFileDialog();
            file.Filter = "image file|*.png";
            if (file.ShowDialog() == DialogResult.OK)
            {
                path = file.FileName;
                pictureBox1.Image = Image.FromFile(path);
            }
        }
    }
}

