﻿using System;

namespace Lab5
{
    public class Phone : IComparable<Phone>
    {
        public string Id { get; set; }
        public string Brand { get; set; }
        public double CostPrice { get; set; } 
        public string ImageUrl { get; set; } 

        public Phone(string id, string brand, double costPrice, string imageUrl)
        {
            Id = id;
            Brand = brand;
            CostPrice = costPrice;
            ImageUrl = imageUrl;
        }

        public double CalculateSellingPrice()
        {
            if (Brand.Equals("Iphone", StringComparison.OrdinalIgnoreCase))
            {
                return 1.5 * CostPrice;
            }
            else
            {
                return 1.3 * CostPrice;
            }
        }

        public int CompareTo(Phone other)
        {
            if (other == null) return 1;

            return other.CostPrice.CompareTo(CostPrice);
        }
    }
}

