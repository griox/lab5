﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Lab5
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Phone> phoneList = LoadPhoneList();

            int choice;
            do
            {
                Console.WriteLine("1. Hien thi danh sach Phone");
                Console.WriteLine("2. Them 1 Phone");
                Console.WriteLine("3. Xoa mot Phone");
                Console.WriteLine("4. Tinh gia ban cua mot loai Phone");
                Console.WriteLine("5. In sach sach Phone");
                Console.WriteLine("0. Thoat");

                Console.Write("Chon 1 tuy chon: ");
                if (int.TryParse(Console.ReadLine(), out choice))
                {
                    switch (choice)
                    {
                        case 1:
                            DisplayPhoneList(phoneList);
                            break;
                        case 2:
                            AddPhone(phoneList);
                            break;
                        case 3:
                            RemovePhone(phoneList);
                            break;
                        case 4:
                            CalculateSellingPrice(phoneList);
                            break;
                        case 5:
                            SortByCostPriceDescending(phoneList);
                            break;
                        case 0:
                            Console.WriteLine("Chuong trinh ket thuc.");
                            break;
                        default:
                            Console.WriteLine("Khong hop le, vui long chon lai.");
                            break;
                    }
                }
                else
                {
                    Console.WriteLine("Vui long chon 1 so nguyen");
                }

                Console.WriteLine();
            } while (choice != 0);
        }

        static List<Phone> LoadPhoneList()
        {
            List<Phone> phones = new List<Phone>();

            string fileName = "\\\\Mac\\Home\\Downloads\\Lab5\\Phones.txt";

            try
            {
                if (File.Exists(fileName))
                {
                    using (StreamReader sr = new StreamReader(fileName))
                    {
                        int count = int.Parse(sr.ReadLine());
                        for (int i = 0; i < count; i++)
                        {
                            string id = sr.ReadLine();
                            string brand = sr.ReadLine();
                            double costPrice = double.Parse(sr.ReadLine());
                            string imageUrl = sr.ReadLine();

                            Phone newPhone = new Phone(id, brand, costPrice, imageUrl);
                            phones.Add(newPhone);
                        }
                    }
                }
                else
                {
                    Console.WriteLine($"File {fileName} does not exist.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error reading file: {ex.Message}");
            }

            return phones;
        }

        static void DisplayPhoneList(List<Phone> phoneList)
        {
            Console.WriteLine("\nDS Phone:");
            foreach (var phone in phoneList)
            {
                Console.WriteLine($"ID: {phone.Id}, Nhan hieu: {phone.Brand}, Gia nhap: {phone.CostPrice}");
            }
        }

        static void AddPhone(List<Phone> phoneList)
        {
            Console.Write("\nID: ");
            string id = Console.ReadLine();

            Console.Write("Nhan hieu: ");
            string brand = Console.ReadLine();

            Console.Write("Gia nhap: ");
            double costPrice = double.Parse(Console.ReadLine());

            Console.Write("URL hinh anh: ");
            string imageUrl = Console.ReadLine();

            Phone newPhone = new Phone(id, brand, costPrice, imageUrl);
            phoneList.Add(newPhone);

            Console.WriteLine("Da them 1 Phone moi vao danh sach");
        }

        static void RemovePhone(List<Phone> phoneList)
        {
            Console.Write("\nNhap ID cua Phone can xoa");
            string idToRemove = Console.ReadLine();

            Phone phoneToRemove = phoneList.FirstOrDefault(p => p.Id == idToRemove);

            if (phoneToRemove != null)
            {
                phoneList.Remove(phoneToRemove);
                Console.WriteLine($"Da xoa Phone co ID {idToRemove} khoi danh sach.");
            }
            else
            {
                Console.WriteLine($"Khong tim thay Phone co ID {idToRemove} trong danh sach.");
            }
        }

        static void CalculateSellingPrice(List<Phone> phoneList)
        {
            Console.Write("\nNhap ID cua Phone can tinh gia ban: ");
            string idToCalculate = Console.ReadLine();

            Phone phoneToCalculate = phoneList.FirstOrDefault(p => p.Id == idToCalculate);

            if (phoneToCalculate != null)
            {
                double sellingPrice = phoneToCalculate.CalculateSellingPrice();
                Console.WriteLine($"Gia ban cua Phone co ID {idToCalculate}: {sellingPrice}");
            }
            else
            {
                Console.WriteLine($"Khong tim thay Phone co ID {idToCalculate} trong danh sach.");
            }
        }

        static void SortByCostPriceDescending(List<Phone> phoneList)
        {
            List<Phone> sortedList = phoneList.OrderByDescending(p => p.CostPrice).ToList();

            Console.WriteLine("\nDanh sach Phone theo gia nhap giam dan:");
            foreach (var phone in sortedList)
            {
                Console.WriteLine($"ID: {phone.Id}, Nhan hieu: {phone.Brand}, Gia nhap: {phone.CostPrice}");
            }
        }
    }
}
