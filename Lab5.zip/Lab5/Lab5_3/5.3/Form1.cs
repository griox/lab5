using System.Security.Cryptography;

namespace _5._3
{
    public partial class Form1 : Form
    {
        
        List<Phone> list = new List<Phone>();
        string path = "image.jpg";
        public Form1()
        {
            


            InitializeComponent();
            button1.Click += Button1_click;
            button2.Click += Button2_click;
            button3.Click += Button3_click; 
            button4.Click += Button4_click;
            button5.Click += Button5_click;
        }

    
        public void ReadFile()
        {
           list = new List<Phone>();  
            try
            {
                FileStream f = new FileStream("\\\\Mac\\Home\\Documents\\Lab5\\5.3\\5.3\\phone.txt", FileMode.Open, FileAccess.Read);
                StreamReader rd = new StreamReader(f);
                string line;
                while((line = rd.ReadLine()) != null)
                {
                    string id = line;
                    string name = rd.ReadLine() ?? string.Empty;
                    if (float.TryParse(rd.ReadLine(), out float gianhap))
                    {
                        string img = rd.ReadLine() ?? "default image";
                        Phone phone = new Phone(id, name, gianhap, img);
                        list.Add(phone);
                    }

                }
              
            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            ReadFile();
            dataGridView1.DataSource = list;
        }
        private void Button1_click(object sender, EventArgs e)
        {
            Phone ph = new Phone(textBox1.Text, comboBox1.Text, float.Parse(textBox3.Text), path);
            list.Add(ph);
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = list;
            textBox1.Text = "";
            textBox3.Clear();
        }
        private void Button2_click(object sender, EventArgs e)
        {
            for(int i =1;i<list.Count;i++)
            {
                if (list[i].Id == textBox1.Text)
                {
                    list.RemoveAt(i);
                    break;
                }
                dataGridView1.DataSource = null;
                dataGridView1.DataSource = list;
                textBox1.Text = "";
            }
        }
        private void Button3_click(object sender, EventArgs e)
        {
            Phone p = list.Find(c => c.Id == textBox1.Text);
            if(p!=null)
            {
                textBox2.Text = p.Cost().ToString();
            }
        }
        private void Button4_click(object sender, EventArgs e)
        {
            list.Sort();
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = list;
        }

        private void Button5_click(object sender, EventArgs e)
        {
            Close(); 
        }
        private void PictureBox1_click(object sender, EventArgs e)
        {
  
            OpenFileDialog file = new OpenFileDialog();
            file.Filter = "image file|*.png";
            if (file.ShowDialog() == DialogResult.OK)
            {
                path = file.FileName;
                pictureBox1.Image = Image.FromFile(path);
            }

        }


    }
}
