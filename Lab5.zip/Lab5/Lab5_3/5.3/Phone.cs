﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace _5._3
{
    internal class Phone : IComparable<Phone>
    {
        public string Id { get; init; }
        public string Name { get; init; }
        public float Gianhap { get; init; }
        public string Img { get; init; }
        public Phone(string id, string name , float gianhap, string img)
        {
            Id = id;
            Name = name;
            Gianhap = gianhap;
            Img = img;

        }
        public float Cost()
        {
            if (Name.CompareTo("iphone") == 0)
            {
                return 1.5f * Gianhap;
            }
            else
            {
                return 1.3f * Gianhap;
            }
        }
        public int CompareTo(Phone? other)
        {
            return Gianhap.CompareTo(other?.Gianhap);
        }

    }
   
   
}
