namespace _5._4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            button1.Click += Button1_Click;
        }
        private void Button1_Click(object sender, EventArgs e)
        {
            string tai_khoan = textBox1.Text;
            string mat_khau =textBox2.Text;
            if(tai_khoan =="admin" && mat_khau == "123")
            {
                MessageBox.Show("Login sucessful");
                this.Close();
            }
            else
            {
                MessageBox.Show("Login Failed");
                this.Close();
            }
        }
    }
}
