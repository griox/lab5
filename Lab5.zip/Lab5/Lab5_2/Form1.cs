namespace _5._2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            radioButton1.Checked = true;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private double PTbac1(double a, double b)
        {
            if (a == 0)
            {
                MessageBox.Show("Loi tham so");
                return double.NaN;
            }
            else
            {
                double result = -b / a;
                return Math.Round(result, 5);
            }
        }

        private string PTbac2(double a, double b, double c)
        {
            double delta = b * b - 4 * a * c;
            if (delta < 0)
            {
                return "PTVN";
            }
            else if (delta == 0)
            {
                return $"PT co nghiem kep x = {(-b / (2 * a)):F5}";
            }
            else if (delta > 0)
            {
                double x1 = (-b + Math.Sqrt(delta)) / (2 * a);
                double x2 = (-b - Math.Sqrt(delta)) / (2 * a);
                return $"x1 ={x1:F5}\tx2 ={x2:F5} ";
            }
            else
            {
                return "Loi tham so";
            }
        }

        private void Button1_click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                if (double.TryParse(textBox1.Text, out double a) && double.TryParse(textBox2.Text, out double b))
                {
                    double kq = PTbac1(a, b);
                    textBox4.Text = $"x = {kq}";
                }
                else
                {
                    MessageBox.Show("Loi tham so");
                }
            }
            if (radioButton2.Checked)
            {
                if (double.TryParse(textBox1.Text, out double a) && double.TryParse(textBox2.Text, out double b) && double.TryParse(textBox3.Text, out double c))
                {
                    string kq = PTbac2(a, b, c);
                    textBox4.Text = kq;

                }
            }
        }
        private void Button2_close(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Ban co chac dong ung dung?", "Xac nhan dong ung dung", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                this.Close();
            }

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}