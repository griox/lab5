﻿namespace _5._2
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            groupBox1 = new GroupBox();
            radioButton2 = new RadioButton();
            radioButton1 = new RadioButton();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            textBox3 = new TextBox();
            button1 = new Button();
            button2 = new Button();
            label5 = new Label();
            textBox4 = new TextBox();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Firebrick;
            label1.Location = new Point(311, 71);
            label1.Name = "label1";
            label1.Size = new Size(431, 56);
            label1.TabIndex = 0;
            label1.Text = "Giải phương trình";
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(radioButton2);
            groupBox1.Controls.Add(radioButton1);
            groupBox1.Font = new Font("Arial", 13.875F, FontStyle.Bold, GraphicsUnit.Point, 0);
            groupBox1.Location = new Point(64, 209);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(502, 185);
            groupBox1.TabIndex = 1;
            groupBox1.TabStop = false;
            groupBox1.Text = "Chọn phương trình";
            groupBox1.Enter += groupBox1_Enter;
            // 
            // radioButton2
            // 
            radioButton2.AutoSize = true;
            radioButton2.Font = new Font("Arial", 13.875F);
            radioButton2.Location = new Point(15, 120);
            radioButton2.Name = "radioButton2";
            radioButton2.Size = new Size(268, 46);
            radioButton2.TabIndex = 1;
            radioButton2.Text = "ax^2+bx+c=0";
            radioButton2.UseVisualStyleBackColor = true;
            radioButton2.CheckedChanged += this.radioButton2_CheckedChanged;
            // 
            // radioButton1
            // 
            radioButton1.AutoSize = true;
            radioButton1.Checked = true;
            radioButton1.Font = new Font("Arial", 13.875F);
            radioButton1.Location = new Point(15, 65);
            radioButton1.Name = "radioButton1";
            radioButton1.Size = new Size(172, 46);
            radioButton1.TabIndex = 0;
            radioButton1.TabStop = true;
            radioButton1.Text = "ax+b=0";
            radioButton1.UseVisualStyleBackColor = true;
            radioButton1.CheckedChanged += this.radioButton1_CheckedChanged;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Arial", 12F);
            label2.ForeColor = Color.Crimson;
            label2.Location = new Point(657, 212);
            label2.Name = "label2";
            label2.Size = new Size(123, 36);
            label2.TabIndex = 2;
            label2.Text = "Hệ số a";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Arial", 12F);
            label3.ForeColor = Color.Crimson;
            label3.Location = new Point(657, 287);
            label3.Name = "label3";
            label3.Size = new Size(123, 36);
            label3.TabIndex = 3;
            label3.Text = "Hệ số b";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Arial", 12F);
            label4.ForeColor = Color.Crimson;
            label4.Location = new Point(657, 371);
            label4.Name = "label4";
            label4.Size = new Size(122, 36);
            label4.TabIndex = 4;
            label4.Text = "Hệ số c";
            // 
            // textBox1
            // 
            textBox1.Font = new Font("Arial", 12F);
            textBox1.Location = new Point(798, 204);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(188, 44);
            textBox1.TabIndex = 5;
            // 
            // textBox2
            // 
            textBox2.Font = new Font("Arial", 12F);
            textBox2.Location = new Point(798, 285);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(188, 44);
            textBox2.TabIndex = 6;
            textBox2.TextChanged += textBox2_TextChanged;
            // 
            // textBox3
            // 
            textBox3.Font = new Font("Arial", 12F);
            textBox3.Location = new Point(798, 363);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(188, 44);
            textBox3.TabIndex = 7;
            // 
            // button1
            // 
            button1.BackColor = SystemColors.InactiveBorder;
            button1.FlatStyle = FlatStyle.Popup;
            button1.Font = new Font("Arial", 12F, FontStyle.Bold);
            button1.ForeColor = Color.FromArgb(192, 0, 0);
            button1.Location = new Point(185, 601);
            button1.Name = "button1";
            button1.Size = new Size(233, 52);
            button1.TabIndex = 8;
            button1.Text = "Tính";
            button1.UseVisualStyleBackColor = false;
            button1.Click += Button1_click;
            // 
            // button2
            // 
            button2.BackColor = SystemColors.InactiveBorder;
            button2.FlatStyle = FlatStyle.Popup;
            button2.Font = new Font("Arial", 12F, FontStyle.Bold);
            button2.ForeColor = Color.FromArgb(192, 0, 0);
            button2.Location = new Point(675, 601);
            button2.Name = "button2";
            button2.Size = new Size(210, 52);
            button2.TabIndex = 9;
            button2.Text = "Thoát";
            button2.UseVisualStyleBackColor = false;
            button2.Click += Button2_close;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.FlatStyle = FlatStyle.Flat;
            label5.Font = new Font("Arial", 12F);
            label5.ForeColor = Color.Crimson;
            label5.Location = new Point(128, 460);
            label5.Name = "label5";
            label5.Size = new Size(123, 36);
            label5.TabIndex = 10;
            label5.Text = "Kết quả";
            // 
            // textBox4
            // 
            textBox4.Font = new Font("Arial", 12F);
            textBox4.Location = new Point(276, 457);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(272, 44);
            textBox4.TabIndex = 11;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(192F, 192F);
            AutoScaleMode = AutoScaleMode.Dpi;
            BackColor = Color.White;
            ClientSize = new Size(1075, 709);
            Controls.Add(textBox4);
            Controls.Add(label5);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(textBox3);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(groupBox1);
            Controls.Add(label1);
            Font = new Font("Arial", 13.875F);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private GroupBox groupBox1;
        private RadioButton radioButton1;
        private RadioButton radioButton2;
        private Label label2;
        private Label label3;
        private Label label4;
        private TextBox textBox1;
        private TextBox textBox2;
        private TextBox textBox3;
        private Button button1;
        private Button button2;
        private Label label5;
        private TextBox textBox4;
    }
}
